package tiger.Absyn;
import tiger.Symbol.Symbol;
public class NilExp extends Exp {
  public NilExp(int l, int c) {line = l; colume = c;}
}
