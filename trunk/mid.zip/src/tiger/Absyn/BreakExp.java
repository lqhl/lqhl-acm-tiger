package tiger.Absyn;
import tiger.Symbol.Symbol;
public class BreakExp extends Exp {
   public BreakExp(int l, int c) {line = l; colume = c;}
}
