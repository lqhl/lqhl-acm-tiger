package tiger.Absyn;
import tiger.Symbol.Symbol;
abstract public class Ty extends Absyn {}
