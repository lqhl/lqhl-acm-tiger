package tiger.Absyn;
import tiger.Symbol.Symbol;
abstract public class Var extends Absyn {
}
