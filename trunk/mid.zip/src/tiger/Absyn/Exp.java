package tiger.Absyn;
import tiger.Symbol.Symbol;
abstract public class Exp extends Absyn {
}
