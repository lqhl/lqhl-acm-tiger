package tiger.Translate;

public abstract class Exp {

}
