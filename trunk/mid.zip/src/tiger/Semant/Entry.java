package tiger.Semant;

public abstract class Entry {

}
