package tiger.Semant;
import tiger.Types.*;

public class VarEntry extends Entry {
	Type ty;
	VarEntry(Type t) {
		ty = t;
	}
}
