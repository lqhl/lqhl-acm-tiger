package tiger.Semant;
import tiger.Types.*;

public class ForVarEntry extends VarEntry {
	ForVarEntry(Type t) {
		super(t);
	}
}
